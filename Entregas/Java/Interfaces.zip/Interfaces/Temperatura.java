public interface Temperatura {
    String determinarTemperatura();
}
