/**
 * Estadistica
 */
public interface Estadistica {
    double minimo();

    double maximo();
}